import os
from typing import Optional
from fastapi import APIRouter, Request, Form, Query, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import pathlib

from ..db import get_conn
from ..utils.embeddings import embed, embedding_to_vector_str
from ..utils.json_io import append_question_to_json, remove_question_from_json
from ..utils.categories import load_categories, add_category_if_new
from ..logger import logger
from ..config import settings
from ..utils.chroma_service import chroma_service


# Router ve template setup
router = APIRouter()
TPL_DIR = pathlib.Path(__file__).parent.parent / "templates"
templates = Jinja2Templates(directory=str(TPL_DIR))

# Environment variables
DEFAULT_THRESHOLD = settings.SIM_THRESHOLD


@router.post("/check-duplicate")
async def check_duplicate(
    request: Request,
    question: str = Form(...),
    th: Optional[float] = Query(None),
    k: int = Query(3, ge=1, le=10),
):
    """Benzer soru kontrolü yapar - ChromaDB ile"""

    # BASİT VALIDATION
    if not question or not question.strip():
        return {"duplicate": False, "results": [], "error": "Soru boş olamaz"}
    if len(question.strip()) < 3:
        return {"duplicate": False, "results": [], "error": "Soru çok kısa"}
    
    # Embedding hesapla
    q = embed(question)
    
    # ChromaDB'de benzer soruları ara
    threshold = float(th) if th is not None else DEFAULT_THRESHOLD
    similar_questions = chroma_service.search_similar(
        q.tolist(), top_k=k, threshold=threshold
    )
    
    # Benzerlik kontrolü
    dup = len(similar_questions) > 0
    
    logger.debug(
        "Duplicate check qlen=%s th=%.2f topk=%s result=%s req_id=%s ip=%s",
        len(question), threshold, k, {"duplicate": dup},
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    return {
        "duplicate": dup, 
        "threshold": threshold,
        "results": [
            {"id": r["id"], "question": r["question"], "sim": float(r["sim"])} 
            for r in similar_questions
        ]
    }


@router.post("/add")
async def add_question(
    request: Request,
    question: str = Form(...),
    answer: str = Form(...),
    keywords: str = Form(...),
    category: str = Form(...),
    created_by: str = Form("anonymous")
):
    """Yeni soru ekler - ChromaDB ile"""
    # Embedding hesapla
    vec = embed(question)
    vec_str = embedding_to_vector_str(vec)

    # Veritabanına ekle ve ID al - created_by alanını da ekle!
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "INSERT INTO questions (question, answer, keywords, category, embedding, created_by) "
            "VALUES (%s, %s, %s, %s, %s::vector, %s) RETURNING id",
            (question, answer, keywords, category, vec_str, created_by)
        )
        result = cur.fetchone()
        new_id = result.get("id") if hasattr(result, 'get') else result[0]
        conn.commit()

    # ChromaDB'ye ekle
    chroma_service.add_question(
        new_id, question, answer, keywords, category, vec.tolist()
    )

    # JSON dosyasına ekle
    question_data = {
        "id": new_id, 
        "question": question, 
        "answer": answer, 
        "keywords": keywords, 
        "category": category,
        "created_by": created_by
    }
    append_question_to_json(question_data)

    # Kategoriyi güncelle (yoksa ekle)
    add_category_if_new(category)

    logger.info(
        "Added id=%s cat=%s qlen=%s by=%s req_id=%s ip=%s",
        new_id, category, len(question), created_by,
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    return {"ok": True, "id": new_id}


@router.get("/questions/{qid}")
def get_question_detail(request: Request, qid: int):
    """Tek bir sorunun detaylarını getirir"""
    logger.debug(
        "Get question detail id=%s req_id=%s ip=%s",
        qid,
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT id, question, answer, keywords, category, created_at, created_by "
            "FROM questions WHERE id = %s",
            (qid)
        )
        result = cur.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="Soru bulunamadı")
        return result


@router.get("/questions")
def list_questions(
    request: Request,
    limit: int = 50, 
    offset: int = 0
):
    """Soruları listeler"""
    logger.debug(
        "List questions limit=%s offset=%s req_id=%s ip=%s",
        limit, offset,
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT id, question, answer, keywords, category, created_at, created_by "
            "FROM questions ORDER BY id DESC LIMIT %s OFFSET %s",
            (limit, offset)
        )
        return cur.fetchall()


@router.get("/questions-table", response_class=HTMLResponse)
def questions_table(request: Request):
    """Soruları HTML tablosu olarak döndürür"""
    logger.debug(
        "Questions table req_id=%s ip=%s",
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT id, question, category, created_at FROM questions ORDER BY id DESC LIMIT 100"
        )
        rows = cur.fetchall()
    return templates.TemplateResponse("questions.html", {"request": request, "rows": rows})


@router.get("/questions/search")
def search_questions(
    request: Request,
    query: str, 
    limit: int = 50, 
    offset: int = 0
):
    """Soruları arar"""
    logger.debug(
        "Search query=%s limit=%s offset=%s req_id=%s ip=%s",
        query, limit, offset,
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    like_pattern = f"%{query}%"
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute("""
            SELECT id, question, answer, keywords, category, created_at, created_by
            FROM questions
            WHERE question ILIKE %s OR answer ILIKE %s OR keywords ILIKE %s OR category ILIKE %s
            ORDER BY id DESC
            LIMIT %s OFFSET %s
        """, (like_pattern, like_pattern, like_pattern, like_pattern, limit, offset))
        return cur.fetchall()


@router.get("/categories.json")
def get_categories(request: Request):
    """Kategorileri JSON formatında döndürür"""
    logger.debug(
        "Get categories req_id=%s ip=%s",
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    return load_categories()


@router.put("/questions/{qid}")
async def update_question(
    request: Request,
    qid: int,
    question: str = Form(...),
    answer: str = Form(...),
    keywords: str = Form(...),
    category: str = Form(...),
    updated_by: str = Form("anonymous")
):
    """Soru günceller - ChromaDB ile"""
    # Yeni embedding hesapla
    vec = embed(question)
    vec_str = embedding_to_vector_str(vec)

    # Veritabanında güncelle
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute(
            "UPDATE questions SET question = %s, answer = %s, keywords = %s, "
            "category = %s, embedding = %s::vector, updated_at = NOW() "
            "WHERE id = %s RETURNING id",
            (question, answer, keywords, category, vec_str, qid)
        )
        result = cur.fetchone()
        if not result:
            raise HTTPException(status_code=404, detail="Soru bulunamadı")
        conn.commit()

    # ChromaDB'den eski kaydı sil ve yenisini ekle
    chroma_service.delete_question(qid)
    chroma_service.add_question(
        qid, question, answer, keywords, category, vec.tolist()
    )

    # JSON dosyasında güncelle
    from ..utils.json_io import json_manager
    json_manager.update_question(qid, {
        "question": question,
        "answer": answer,
        "keywords": keywords,
        "category": category
    })

    # Kategoriyi güncelle (yoksa ekle)
    add_category_if_new(category)

    logger.info(
        "Updated id=%s cat=%s qlen=%s by=%s req_id=%s ip=%s",
        qid, category, len(question), updated_by,
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    return {"ok": True, "id": qid}


@router.delete("/questions/{qid}")
async def delete_question(
    request: Request,
    qid: int,
    deleted_by: str = Form("anonymous")
):
    """Soru siler - ChromaDB ile"""
    # Veritabanından sil
    with get_conn() as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM questions WHERE id = %s RETURNING id", (qid,))
        deleted = cur.fetchone()
        if not deleted:
            raise HTTPException(status_code=404, detail="Soru bulunamadı")
        conn.commit()

    # ChromaDB'den sil
    chroma_service.delete_question(qid)
    
    # JSON dosyasından sil
    success = remove_question_from_json(qid)
    
    logger.info(
        "Deleted id=%s deleted_by=%s req_id=%s ip=%s",
        qid, deleted_by,  # 👈 Silen kişiyi logla (sadece log için)
        getattr(request.state, 'request_id', 'unknown'),
        getattr(request.state, 'client_ip', 'unknown')
    )
    
    return {"ok": True, "deleted_id": qid, "json_updated": success}