#!/bin/bash
curl -fsSL https://ollama.ai/install.sh | sh
